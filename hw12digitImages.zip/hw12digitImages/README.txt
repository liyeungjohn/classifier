Image files for the Digits Dataset

This contains images of each of the digits, for ease of visualization.
You shouldn't need to use any of these in your machine learning algorithm,
we provide this just in case it helps you visualize and debug your
algorithm.

- train/trainDigitN.png contains a PNG image of the image of the nth handwritten image in the training set.
- val/valDigitN.png contains a PNG image of the image of the nth handwritten image in the validation set.
- test/testDigitN.png contains a PNG image of the image of the nth handwritten image in the test set.
